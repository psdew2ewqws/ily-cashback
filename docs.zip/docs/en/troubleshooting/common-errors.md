# Troubleshooting Common Errors

Solutions to frequent issues in ILY Cash.

---

## 🚫 Login Issues

### Error: Cannot Login - Phone Number Not Recognized

![Login Error](../../images/screenshots/error-login-failed.png)
*Screenshot: Login error message*

**Problem:** Your phone number is not in the system

**Solutions:**
1. **Verify phone number format**
   - Must be: 07XXXXXXXX
   - Example: 0791234567
   - Don't include: +962, spaces, dashes

2. **Contact ILY Support**
   - Your account may not be activated
   - Provide your phone number to support team

3. **Check with manager**
   - Confirm you're registered as a merchant
   - Manager may need to add you to system

---

### Error: Login Button Not Working

**Problem:** Clicking login does nothing

**Solutions:**
1. **Check internet connection**
   - ILY Cash requires active internet
   - Test: Open browser, visit any website

2. **Restart the app**
   - Close ILY Cash completely
   - Reopen and try again

3. **Verify phone number is complete**
   - Must have 10 digits
   - Must start with 07

---

## 💰 Cashback Processing Errors

### Error: "Bill amount too low" (Below 2 JOD)

![Low Amount Error](../../images/screenshots/error-bill-too-low.png)
*Screenshot: Minimum amount error dialog in Arabic*

**Error Message:**
- "⚠️ المبلغ قليل جداً" (Amount too low)
- "الحد الأدنى للفاتورة: 2.00 دينار" (Minimum bill: 2.00 JOD)

**Solutions:**
1. **Verify bill amount**
   - Check you entered correct amount
   - Minimum allowed: 2.00 JOD

2. **If bill is actually below 2 JOD:**
   - Customer doesn't qualify for cashback
   - Inform customer of minimum requirement

3. **Decimal point check:**
   - ✅ Correct: 2.50
   - ❌ Wrong: 2,50 (comma instead of period)

---

### Error: Customer Not Found

![Customer Not Found](../../images/screenshots/error-customer-not-found.png)
*Screenshot: Customer not found error*

**Error Message:**
- "Customer not registered in ILY system"
- Phone number not recognized

**Solutions:**
1. **Double-check phone number**
   - Ask customer to verify their number
   - Common mistake: wrong digit

2. **Try alternative number**
   - Customer may have multiple numbers
   - Ask if they registered with different number

3. **Customer needs to register**
   - Customer must sign up with ILY first
   - Direct them to ILY website or app
   - They can register using their phone

4. **Format check:**
   - ✅ 0791234567
   - ❌ +962791234567 (don't include country code)
   - ❌ 791234567 (missing 0)

---

### Error: Blacklisted Customer (Fraud Alert)

![Fraud Alert](../../images/screenshots/fraud-alert.png)
*Screenshot: Red fraud warning dialog*

**Error Message:**
- "⚠️ تحذير: عميل محظور" (Warning: Blacklisted Customer)
- "لا يمكن معالجة الكاشباك" (Cannot process cashback)
- Red warning dialog

**What This Means:**
- Customer flagged for fraudulent activity
- System prevents cashback to protect you
- This is a **security feature**

**What To Do:**
1. **DO NOT** process cashback
2. **DO NOT** try to bypass this warning
3. **Politely tell customer:**
   - "There's an issue with your account"
   - "Please contact ILY support"
   - Don't mention "fraud" or "blacklist"

4. **Click "حسناً" (OK)** to close dialog
5. **Return to home screen**

**If Customer Argues:**
- Stay professional and calm
- Repeat: "Please contact ILY support"
- Do not process transaction manually
- This protects your store from fraud losses

---

### Error: Duplicate Bill Number

**Error Message:**
- "Bill number already used"
- "This bill was already processed"

**Solutions:**
1. **Check bill number accuracy**
   - You may have entered wrong number
   - Verify against physical receipt

2. **If bill was already processed:**
   - Check transaction history
   - Don't process again (double cashback)

3. **If this is a new bill:**
   - Use slightly different bill number
   - Example: Add letter or suffix (Bill123 → Bill123A)

---

## 🌐 Connection and Network Errors

### Error: Cannot Connect to Server

![Connection Error](../../images/screenshots/error-connection.png)
*Screenshot: Network connection error*

**Error Message:**
- "Cannot connect to server"
- "Network error - check connection"

**Solutions:**

**1. Check Internet Connection**
- Open web browser
- Try loading any website
- If no internet: restart router

**2. Check Server Status Indicator**
![Server Status](../../images/screenshots/server-status-indicator.png)
*Screenshot: Server status in app (green = connected, red = disconnected)*

- Top of app shows connection status
- 🟢 Green = Connected
- 🔴 Red = Disconnected

**3. Wait and Retry**
- Server may be temporarily down
- Wait 1-2 minutes
- Try processing again

**4. Restart ILY Cash**
- Close app completely
- Reopen and login again
- Try transaction again

**5. Check Windows Firewall**
- ILY Cash may be blocked
- Windows Settings → Security → Firewall
- Allow ILY Cash through firewall

---

### Error: Request Timeout

**Error Message:**
- "Request timed out"
- "Server not responding"

**Solutions:**
1. **Slow internet connection**
   - Check internet speed
   - Close other apps using internet
   - Try again

2. **Server busy**
   - Wait 30 seconds
   - Retry transaction

3. **Restart app**
   - Close and reopen ILY Cash

---

## 🔄 Update Issues

### Issue: Auto-Update Not Working

**Problem:** New version available but not downloading

**Solutions:**

**1. Check Update Settings**
- Updates should check automatically
- 10 seconds after startup
- Daily at 11:00 AM Jordan Time

**2. Manual Check**
- Visit: https://github.com/psdew2ewqws/ily-cashback/releases
- Download latest version manually
- Install over existing version

**3. Verify Internet Connection**
- Updates require internet
- Check connection is stable

**4. Check Windows Permissions**
- Update may need admin rights
- Right-click ILY_Cash.exe
- Select "Run as administrator"

![Run as Admin](../../images/screenshots/run-as-admin.png)
*Screenshot: Right-click menu showing "Run as administrator"*

**5. Firewall Blocking Downloads**
- Windows may block update downloads
- Temporarily disable antivirus
- Try update again
- Re-enable antivirus after

---

### Issue: Update Downloaded but Not Installing

**Problem:** Update stuck in "downloading" or "installing"

**Solutions:**
1. **Close and restart app**
   - Exit ILY Cash completely
   - Reopen - update should resume

2. **Manual update**
   - Download latest version from GitHub
   - Close ILY Cash
   - Extract and replace old files
   - Run new version

---

## 🖥️ App Performance Issues

### Issue: App Running Slow

**Solutions:**
1. **Restart app**
   - Close completely
   - Reopen

2. **Restart computer**
   - May have low memory
   - Restart Windows

3. **Check other running apps**
   - Close unnecessary programs
   - Free up system resources

---

### Issue: App Freezes or Crashes

**Solutions:**
1. **Force close**
   - Press Ctrl + Alt + Delete
   - Open Task Manager
   - Find "ILY_Cash.exe"
   - Click "End Task"

![Task Manager](../../images/screenshots/task-manager-end-task.png)
*Screenshot: Windows Task Manager showing ILY Cash*

2. **Restart app**
   - Reopen ILY Cash
   - Login again

3. **Update to latest version**
   - Check for updates
   - Install newest version
   - Bugs may be fixed

4. **Reinstall app**
   - Uninstall ILY Cash
   - Download fresh copy
   - Install again

---

## 📱 WhatsApp Integration Issues

### Issue: WhatsApp Messages Not Triggering Cashback

**Problem:** Sending message in WhatsApp but nothing happens

**Solutions:**

**1. Verify ILY Cash is Running**
- Check system tray for ILY icon
- App must be running (minimized OK)
- If closed, auto-detection won't work

![System Tray Check](../../images/screenshots/system-tray-check.png)
*Screenshot: ILY Cash icon in Windows system tray*

**2. Verify WhatsApp is Open**
- WhatsApp Desktop OR WhatsApp Web must be open
- Must be logged in and active

**3. Check Message Format**
- Must include: Phone, Bill, Amount
- Example: `0791234567 Bill123 25.50`
- See: [WhatsApp Integration Guide](../how-to/whatsapp-integration.md)

**4. Verify Phone Format**
- Must start with 07
- Must be 10 digits
- ✅ 0791234567
- ❌ +962791234567

**5. Check Amount Format**
- Must be ≥ 2.00 JOD
- Use decimal point: 25.50 (not 25,50)
- Don't include "JOD" text

---

## 🖨️ Printing Issues

### Issue: Receipt Won't Print

**Solutions:**
1. **Check printer connection**
   - Ensure printer is on
   - Check USB/network connection

2. **Check printer settings**
   - Windows Settings → Printers
   - Verify default printer is set

3. **Restart printer**
   - Turn off printer
   - Wait 10 seconds
   - Turn back on

4. **Print test page**
   - Windows Settings → Printers
   - Right-click your printer
   - "Print test page"
   - If this works, ILY should work

---

## 🆘 Getting Help

### When to Contact Support

Contact ILY support if:
- Login fails repeatedly
- Connection errors persist
- App crashes frequently
- Customer account issues
- Fraud alert questions

### How to Contact Support

**Before contacting support, collect:**
1. Your merchant phone number
2. App version (bottom of login screen)
3. Screenshot of error message
4. Steps that caused the problem

**Contact Methods:**
- GitHub Issues: [Report Problem](https://github.com/psdew2ewqws/ily-cashback/issues)
- Email: [Support Email]
- Phone: [Support Phone]

---

## 📋 Quick Troubleshooting Checklist

When something goes wrong:

1. [ ] **Check internet connection** - Open browser, test connection
2. [ ] **Check server status** - Look at indicator in app
3. [ ] **Restart ILY Cash** - Close completely and reopen
4. [ ] **Check for updates** - Install latest version
5. [ ] **Restart computer** - Simple but often effective
6. [ ] **Check Windows firewall** - Ensure ILY Cash is allowed
7. [ ] **Try again** - Many errors are temporary
8. [ ] **Contact support** - If problem persists

---

## 💡 Prevention Tips

**Avoid problems before they happen:**

1. **Keep app updated** - Auto-updates are enabled
2. **Stable internet** - Use reliable connection
3. **Regular restarts** - Restart app daily
4. **Double-check input** - Verify phone numbers and amounts
5. **Follow message formats** - Use correct WhatsApp format
6. **Watch for fraud alerts** - Never ignore blacklist warnings

---

## 📚 Related Documentation

- [Getting Started Guide →](../getting-started/README.md)
- [Process Cashback →](../how-to/process-cashback.md)
- [WhatsApp Integration →](../how-to/whatsapp-integration.md)
- [FAQ →](../faq/general.md)
