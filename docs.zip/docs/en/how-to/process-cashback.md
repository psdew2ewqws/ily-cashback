# How to Process Cashback

Step-by-step guide to giving cashback to customers.

---

## 📝 Before You Start

**You will need:**
- Customer's phone number (07XXXXXXXX)
- Bill number (receipt number)
- Bill total amount (in JOD)

**Important:**
- Minimum bill amount: **2.00 JOD**
- Bills below 2 JOD will show an error
- Customer must be registered in ILY system

---

## 🎯 Processing Cashback - Step by Step

### Step 1: Open Earn Cashback

1. From the **Home Screen**, click **"💰 Earn Cashback"** button

![Home Screen](../../images/screenshots/home-screen-cashback-button.png)
*Screenshot: Home screen with Earn Cashback button highlighted*

---

### Step 2: Enter Customer Phone Number

1. **Click** the "Phone Number" field
2. **Type** customer's phone number (e.g., 0791234567)
3. Number should start with **07**

![Enter Phone](../../images/screenshots/cashback-enter-phone.png)
*Screenshot: Phone number field with example number*

**Common Mistakes:**
- ❌ Don't include country code (+962)
- ❌ Don't include spaces or dashes
- ✅ Correct format: 0791234567

---

### Step 3: Enter Bill Number

1. **Click** the "Bill Number" field
2. **Type** the receipt/invoice number
3. This can be letters and numbers

![Enter Bill Number](../../images/screenshots/cashback-enter-bill.png)
*Screenshot: Bill number field filled*

---

### Step 4: Enter Bill Amount

1. **Click** the "Bill Amount" field
2. **Type** the total amount in Jordanian Dinars
3. Use **numbers only** (e.g., 25.50)

![Enter Amount](../../images/screenshots/cashback-enter-amount.png)
*Screenshot: Amount field showing 25.50*

**Important Rules:**
- Minimum amount: **2.00 JOD**
- Use decimal point for fils (25.50, not 25.500)
- Don't include currency symbol

---

### Step 5: Submit Transaction

1. **Review** all entered information
2. **Click** "Submit" or "Send Cashback" button

![Review and Submit](../../images/screenshots/cashback-review-submit.png)
*Screenshot: All fields filled, submit button highlighted*

---

### Step 6: Wait for Processing

- App will validate customer and bill
- Progress indicator will show
- This usually takes 2-3 seconds

![Processing](../../images/screenshots/cashback-processing.png)
*Screenshot: Loading/processing indicator*

---

## ✅ Success! Cashback Processed

### Success Confirmation

When cashback is successfully processed, you'll see:

![Success Dialog](../../images/screenshots/cashback-success.png)
*Screenshot: Success dialog in Arabic showing bill number and cashback amount*

**Success Dialog Shows:**
- ✅ "تم إرسال الكاشباك بنجاح!" (Cashback sent successfully!)
- 📄 Bill number: Displayed
- 💰 Cashback amount: Amount credited to customer
- 👤 Customer: Last 4 digits of phone (****1234)
- Auto-closes after 10 seconds

### What Happens Next?

1. **Customer receives cashback** in their ILY account immediately
2. **Transaction is recorded** in your transaction history
3. **You return to home screen** automatically

---

## ⚠️ Common Errors and Solutions

### Error: Bill Amount Too Low

**Problem**: Bill is below 2 JOD minimum

![Error Low Amount](../../images/screenshots/error-bill-too-low.png)
*Screenshot: Error dialog showing minimum amount requirement*

**Solution:**
- Check bill amount is correct
- Minimum allowed: **2.00 JOD**
- If bill is actually below 2 JOD, inform customer they don't qualify

---

### Error: Customer Not Found

**Problem**: Phone number not registered in ILY system

![Error Not Found](../../images/screenshots/error-customer-not-found.png)
*Screenshot: Customer not found error*

**Solution:**
1. **Double-check** phone number is correct
2. Ask customer to **verify their number**
3. Customer may need to **register with ILY** first

---

### Error: Blacklisted Customer (Fraud Alert)

**Problem**: Customer flagged for fraudulent activity

![Fraud Alert](../../images/screenshots/fraud-alert.png)
*Screenshot: Red fraud warning dialog in Arabic*

**Error Message:**
- "⚠️ تحذير: عميل محظور" (Warning: Blacklisted Customer)
- "هذا العميل تم إدراجه في القائمة السوداء" (This customer is blacklisted)

**Solution:**
1. **DO NOT** process cashback
2. **Politely decline** - tell customer to contact ILY support
3. **Click "Close"** to return to home
4. Contact ILY support if you have questions

**Important**: This protects your store from fraud. Never override this warning.

---

### Error: Network/Connection Issues

**Problem**: Cannot connect to server

![Connection Error](../../images/screenshots/error-connection.png)
*Screenshot: Network error message*

**Solution:**
1. **Check** your internet connection
2. **Verify** server status indicator (top of screen)
3. **Try again** in a few seconds
4. If problem persists, contact support

---

## 📋 Quick Reference Checklist

Before submitting cashback:

- [ ] Customer phone number (07XXXXXXXX format)
- [ ] Bill number entered correctly
- [ ] Bill amount ≥ 2.00 JOD
- [ ] All fields filled
- [ ] Internet connection active

---

## 🔄 What's Next?

- [View Transaction History →](view-history.md)
- [WhatsApp Auto-Cashback →](whatsapp-integration.md)
- [Troubleshooting Guide →](../troubleshooting/common-errors.md)

---

## 💡 Pro Tips

1. **Keep bills ready** before starting the form
2. **Double-check phone numbers** - most common mistake
3. **Have customer verify** phone number before processing
4. **Process during slow times** if learning the system
5. **Customer gets confirmation SMS** - they should check their phone
