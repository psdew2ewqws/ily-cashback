# WhatsApp Auto-Cashback Integration

Learn how to use WhatsApp messages to automatically trigger cashback.

---

## 🎯 What is WhatsApp Auto-Cashback?

ILY Cash can **automatically detect** when you send specific messages in WhatsApp and **instantly process cashback** - no need to open the app!

**How it works:**
1. You send a specially formatted message in WhatsApp
2. ILY Cash detects the message
3. Cashback is processed automatically
4. You see success confirmation

---

## 📱 Setup Requirements

### Before You Start

**You need:**
- ILY Cash app running in the background
- WhatsApp Desktop or WhatsApp Web open
- Customer information ready (phone, bill number, amount)

**Important:**
- ✅ ILY Cash must be **running** (minimized is OK)
- ✅ WhatsApp must be **open** on your computer
- ❌ Won't work if ILY Cash is closed

---

## 🚀 How to Use WhatsApp Auto-Cashback

### Step 1: Open WhatsApp

1. **Open** WhatsApp Desktop or WhatsApp Web
2. Make sure you're logged in

![WhatsApp Open](../../images/screenshots/whatsapp-open.png)
*Screenshot: WhatsApp Desktop running*

---

### Step 2: Create the Message

You need to send a message with **all three** pieces of information:

**Required Information:**
1. Phone number (07XXXXXXXX)
2. Bill number
3. Bill amount (in JOD)

**Example Messages:**

```
0791234567
Bill123
25.50
```

OR in one line:

```
0791234567 Bill123 25.50
```

![Message Format](../../images/screenshots/whatsapp-message-format.png)
*Screenshot: WhatsApp showing correctly formatted message*

---

### Step 3: Send the Message

1. **Type** the message in any WhatsApp chat
2. **Click** Send

**Tips:**
- You can send to yourself (your own number)
- You can send to a dedicated "ILY Notes" group
- Message doesn't have to go to the customer

![Send Message](../../images/screenshots/whatsapp-send.png)
*Screenshot: Sending WhatsApp message*

---

### Step 4: Automatic Detection

**What happens:**

1. **ILY Cash detects** the message (within 1-2 seconds)
2. **Validates** the information:
   - Phone number format (07XXXXXXXX)
   - Bill number exists
   - Amount ≥ 2.00 JOD
3. **Processes** cashback automatically
4. **Shows** success dialog

![Auto Detection](../../images/screenshots/whatsapp-auto-detect.png)
*Screenshot: ILY Cash app showing auto-detection in action*

---

### Step 5: Success Confirmation

When cashback is processed, you'll see:

![Auto Success](../../images/screenshots/whatsapp-auto-success.png)
*Screenshot: Auto-success dialog showing customer phone (masked)*

**Success Dialog Shows:**
- ✅ "تم استحقاق الكاشباك بنجاح!" (Cashback earned successfully!)
- 👤 Customer: Masked phone (****1234)
- Auto-closes after 10 seconds

---

## ✅ Message Format Examples

### Example 1: Three Lines

```
0791234567
INV-2024-001
45.00
```

### Example 2: One Line (Space-Separated)

```
0791234567 INV-2024-001 45.00
```

### Example 3: With Text Context

```
Customer: 0791234567
Invoice: BILL-443
Amount: 25.50 JOD
```

**What ILY Cash Extracts:**
- Phone: 0791234567
- Bill: BILL-443
- Amount: 25.50

---

## ⚠️ Common Issues and Solutions

### Issue: Not Detecting Messages

**Possible Causes:**
1. ❌ ILY Cash app is closed
2. ❌ WhatsApp is not open
3. ❌ Message format is incorrect

**Solutions:**
1. ✅ Make sure ILY Cash is running (check system tray)
2. ✅ Open WhatsApp Desktop/Web
3. ✅ Use correct format (phone, bill, amount)

![System Tray](../../images/screenshots/system-tray-ily.png)
*Screenshot: ILY Cash icon in Windows system tray*

---

### Issue: Error After Detection

**Error: Bill Amount Too Low**

![Error Low](../../images/screenshots/whatsapp-error-low-amount.png)
*Screenshot: Error dialog for amount below 2 JOD*

**Solution:**
- Check amount is ≥ 2.00 JOD
- Correct format: Use decimal point (2.50, not 2,50)

---

**Error: Invalid Phone Number**

**Possible Causes:**
- Wrong format (missing 07 prefix)
- Extra characters (spaces, dashes)

**Solution:**
- Use format: 07XXXXXXXX
- Example: ✅ 0791234567 | ❌ +962791234567

---

**Error: Customer Blacklisted**

![Fraud Alert](../../images/screenshots/whatsapp-fraud-alert.png)
*Screenshot: Fraud warning from auto-detection*

**Solution:**
- DO NOT process
- Customer is flagged for fraud
- Ask customer to contact ILY support

---

## 🔒 Security Features

### Validation Before Processing

ILY Cash validates EVERY auto-triggered request:

1. **Phone Format**: Must be 07XXXXXXXX
2. **Amount Check**: Must be ≥ 2.00 JOD
3. **Customer Status**: Checks blacklist
4. **Bill Format**: Validates bill number

**Fraud Protection:**
- Blacklisted customers are rejected immediately
- You'll see red warning dialog
- Transaction is blocked

![Validation Flow](../../images/screenshots/whatsapp-validation-flow.png)
*Diagram: Auto-cashback validation steps*

---

## 💡 Best Practices

### 1. Create a Dedicated Chat

**Recommendation:** Create a WhatsApp group for ILY transactions

1. Create group: "ILY Cashback"
2. Add only yourself
3. Send all cashback messages there
4. Easy to review history

![Dedicated Chat](../../images/screenshots/whatsapp-dedicated-chat.png)
*Screenshot: WhatsApp group for ILY transactions*

---

### 2. Message Templates

Save these message templates in Notes:

**Template 1:**
```
[PHONE]
[BILL]
[AMOUNT]
```

**Template 2:**
```
[PHONE] [BILL] [AMOUNT]
```

Copy, replace placeholders, send!

---

### 3. Double-Check Before Send

**Checklist before sending:**
- [ ] Phone number starts with 07
- [ ] Bill number is correct
- [ ] Amount has decimal point if needed
- [ ] Amount ≥ 2.00 JOD

---

### 4. Keep ILY Cash Running

**Tips:**
- Minimize to system tray (don't close)
- ILY Cash icon should be visible in tray
- Right-click icon → "Keep running in background"

![Keep Running](../../images/screenshots/system-tray-menu.png)
*Screenshot: System tray right-click menu*

---

## 🔄 Troubleshooting Checklist

If auto-cashback not working:

1. [ ] **ILY Cash is running?** Check system tray
2. [ ] **WhatsApp is open?** Desktop or Web must be active
3. [ ] **Message format correct?** Phone, bill, amount present
4. [ ] **Phone format valid?** Starts with 07, 10 digits total
5. [ ] **Amount valid?** ≥ 2.00 JOD, uses decimal point
6. [ ] **Internet connected?** Check connection
7. [ ] **Try manual cashback** - Does regular form work?

---

## 📊 Comparing Manual vs Auto

| Feature | Manual Entry | WhatsApp Auto |
|---------|-------------|---------------|
| **Speed** | ~30 seconds | ~5 seconds |
| **Errors** | More typing errors | Copy-paste accurate |
| **Convenience** | Switch to ILY app | Stay in WhatsApp |
| **Best For** | Single transactions | Bulk processing |

**Recommendation:** Use WhatsApp auto for busy times, manual for learning.

---

## 🆘 Need Help?

- [Troubleshooting Guide →](../troubleshooting/common-errors.md)
- [Manual Cashback Process →](process-cashback.md)
- [FAQ →](../faq/general.md)

---

## 🎓 Pro Tips

1. **Practice with test messages** - send to yourself first
2. **Keep format consistent** - pick one template and stick to it
3. **Use copy-paste** - reduce typing errors
4. **Check success dialog** - always verify before moving on
5. **Review history** - periodically check transaction log
