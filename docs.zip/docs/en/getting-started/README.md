# Getting Started with ILY Cash

Welcome to ILY Cash! This guide will help you get started with the cashback system.

## 📥 Installation

### System Requirements
- **Operating System**: Windows 10 or later
- **Internet Connection**: Required for updates and transactions
- **Screen Resolution**: Minimum 1024x768

### Download and Install

1. **Download ILY Cash**
   - Visit: https://github.com/psdew2ewqws/ily-cashback/releases
   - Download latest version: `ILY_Cash_v3.5.9.zip`

   ![Download Page](../../images/screenshots/download-page.png)
   *Screenshot: GitHub releases page showing download button*

2. **Extract the ZIP File**
   - Right-click on `ILY_Cash_v3.5.9.zip`
   - Select "Extract All..."
   - Choose installation location (e.g., `C:\Program Files\ILY_Cash\`)

   ![Extract ZIP](../../images/screenshots/extract-zip.png)
   *Screenshot: Windows extract dialog*

3. **Run ILY Cash**
   - Open the extracted folder
   - Double-click `ILY_Cash.exe`
   - App will start automatically

   ![App Icon](../../images/screenshots/app-icon.png)
   *Screenshot: ILY Cash executable icon*

### Auto-Update System

✅ **ILY Cash updates automatically!**

- App checks for updates on startup (10 seconds after launch)
- Also checks daily at 11:00 AM Jordan Time
- Updates download and install automatically
- No action needed from you

![Update Notification](../../images/screenshots/update-notification.png)
*Screenshot: Update available dialog*

---

## 🔐 First Launch

### Login Screen

When you first open ILY Cash, you'll see the login screen.

![Login Screen](../../images/screenshots/login-screen.png)
*Screenshot: Login screen with phone number field*

### Enter Your Phone Number

1. **Click** on the phone number field
2. **Type** your registered phone number (07XXXXXXXX)
3. **Click** "Login" button

![Enter Phone](../../images/screenshots/login-enter-phone.png)
*Screenshot: Phone number entered in field*

### Navigate to Home Page

After successful login, you'll see the home dashboard.

![Home Screen](../../images/screenshots/home-screen.png)
*Screenshot: Main dashboard after login*

---

## 🏠 Understanding the Home Screen

### Main Menu Options

The home screen has several key sections:

1. **📊 Dashboard** - Overview of today's activity
2. **💰 Earn Cashback** - Process customer cashback
3. **📜 Transaction History** - View past transactions
4. **⚙️ Settings** - App configuration
5. **🚪 Logout** - Exit your account

![Home Menu](../../images/screenshots/home-menu.png)
*Screenshot: Main menu with all options highlighted*

### Dashboard Widgets

- **Today's Transactions**: Number of cashback processed today
- **Total Amount**: Total cashback given today
- **Server Status**: Connection indicator (green = connected)

![Dashboard Widgets](../../images/screenshots/dashboard-widgets.png)
*Screenshot: Dashboard showing statistics*

---

## ✅ You're Ready!

Congratulations! ILY Cash is now installed and you're logged in.

**Next Steps:**
- [Learn how to process cashback →](../how-to/process-cashback.md)
- [Set up WhatsApp integration →](../how-to/whatsapp-integration.md)
- [View troubleshooting guide →](../troubleshooting/common-errors.md)

---

## 🆘 Need Help?

- [Troubleshooting Guide](../troubleshooting/common-errors.md)
- [FAQ](../faq/general.md)
- GitHub Issues: [Report Problem](https://github.com/psdew2ewqws/ily-cashback/issues)
